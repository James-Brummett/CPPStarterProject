# C++ Starter Template

This is a ready-to-go VSCode C++ project setup with:

- `src/` folder for code
- `build/` folder for compiled output
- `tasks.json` for one-button build/run
- Code Runner compatibility