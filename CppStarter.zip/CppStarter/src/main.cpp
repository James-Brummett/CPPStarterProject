#include <iostream>
#include "utils.h"

int main() {
    std::cout << "Welcome to your C++ starter project!\n";
    std::cout << "2 + 3 = " << add(2,3) << "\n";
    return 0;
}